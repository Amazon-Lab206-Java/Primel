public class Node {
    public Integer value;
    public Node next;

    public Node(Integer value){
        this.value = value;
        this.next = null;
    }

}
