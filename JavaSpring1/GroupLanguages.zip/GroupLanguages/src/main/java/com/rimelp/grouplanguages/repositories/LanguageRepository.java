package com.rimelp.grouplanguages.repositories;

import org.springframework.data.repository.CrudRepository;

import com.rimelp.grouplanguages.models.Language;

public interface LanguageRepository extends CrudRepository<Language, Long>{

}
